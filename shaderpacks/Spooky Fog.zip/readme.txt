This pack applies 4 different effects:

Effect #1: Darkness.
This makes the game a lot darker than normal. Hence the name darkness.
We even ignore minecraft's light levels.
Terrain is always the same brightness regardless of whether or not there's a torch nearby.
It's even the same brightness in caves as it is on the surface.

Effect #2: Desaturation.
This makes the game gray-er and less colorful.

Effect #3: Fog.
This applies a VERY thick layer of fog over everything, somewhat like tiny view distance.

Effect #4: Vignette.
This makes the edges of your screen darker than the middle.

All 4 of these effects are fully configurable.
They even have 2 different options each, so that you can make them behave differently during the day vs. the night.
Fog in particular actually has 4 different options, so that you can change both the density and brightness at any time.